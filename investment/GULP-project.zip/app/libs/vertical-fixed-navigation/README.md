Vertical Fixed Navigation
=========

A side navigation which allows users to easily browse the page, selecting one of its sections and smoothly scrolling to it. It doesn't necessarily replace the main website navigation, but comes in handy for pages packed with content.

[Article on CodyHouse](http://codyhouse.co/gem/vertical-fixed-navigation/)

[Demo](http://codyhouse.co/demo/vertical-fixed-navigation/index.html)
 
[Terms](http://codyhouse.co/terms/)


[© CodyHouse 2014](http://codyhouse.co/)
